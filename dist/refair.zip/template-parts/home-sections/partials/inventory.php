<?php
/**
 * Template part for deposit items
 *
 * @package refair
 */

?>
<div class="deposit-excerpt">
	<div class="inv-left"><div class="img-wrapper"><img src="" alt=""></div></div>
	<div class="inv-right">
		<div class="inv-title"></div>
		<div class="inv-loc"></div>
		<div class="inv-avail"></div>
	</div>
	<div class="read-more"></div>
</div>
