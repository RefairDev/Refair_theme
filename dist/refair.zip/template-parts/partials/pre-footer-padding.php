<?php
/**
 *  Template to insert for padding
 *
 * @package refair
 */

?>
<div class="pre-footer-padding">
	<div class="inner"></div>
</div>
