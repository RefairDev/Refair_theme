<?php
/**
 * Template to display deposits map
 *
 * @package refair
 */

?>
<div class="deposits-map" id="maplf-deposits"></div> 
